
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int zenbakia;
		  
		  
		  printf("Sartu zenbaki bat: ");
		  scanf("%d",&zenbakia);
		  
		  if (zenbakia == 0) {
		  		printf("Zenbakia zero da. \n");
		  } else if (zenbakia > 0) {
		  			printf("Zenbakia positiboa da. \n");
		  		} else {
		  			printf("Zenbakia negatiboa da. \n");
				  }
		  
		                              
          return 0;
        

}


