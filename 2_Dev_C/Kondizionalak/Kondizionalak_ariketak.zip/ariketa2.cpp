
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  char karakterea;
		  //char a, e, i, o, u;
		  
		  
		  printf("SARTU KARAKTEREA: ");
		  scanf("%c",&karakterea);
		  
		  if (karakterea == 'a' || karakterea ==  'e' || karakterea ==  'i' || karakterea ==  'o' || karakterea ==  'u') {
		  	printf("Bokala da.");
		  } else {
		  	printf("Kontsonantea da.");
		  }
		  
		                              
          return 0;
        

}
