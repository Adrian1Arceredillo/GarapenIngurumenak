
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int zenbakia;
		  
		  printf("SARTU ZENBAKIA: \n");
		  
		  scanf("%d",&zenbakia);
		  
		  if ((zenbakia%2) == 0) {
		  	printf("%d zenbakia, bikoitia da", zenbakia);
		  } else {
		  		printf("%d zenbakia, bakoitia da", zenbakia);
		  }
		  		                              
          return 0;
        

}
