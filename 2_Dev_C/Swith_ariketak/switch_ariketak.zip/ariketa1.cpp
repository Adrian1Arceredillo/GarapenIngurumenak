
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  char karakterea;
		  
		  
		  printf("Sartu karaktere bat: ");
		  scanf("%c",&karakterea);
		  
		  switch (karakterea) {
		  	
		  	case 'a':
		  		printf("Karakterea bokala da. \n");
		  		break;
			case 'e':
				printf("Karakterea bokala da. \n");
		  		break;
			case 'i':
				printf("Karakterea bokala da. \n");
		  		break;
			case 'o':
				printf("Karakterea bokala da. \n");
		  		break;
			case 'u':
		  		printf("Karakterea bokala da. \n");
		  		break;
		  	default:
		  		printf("Karaketerea kontsonantea da. \n");
		  	
		  }
		  
		                              
          return 0;
        

}
