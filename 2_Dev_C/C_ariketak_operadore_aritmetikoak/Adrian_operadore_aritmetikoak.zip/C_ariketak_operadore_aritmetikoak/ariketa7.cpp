
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  char batu; //comillas simples
		  
		  
		  
		  printf("ASCII KODEA \n");
		  printf("SARTU KARAKTEREA: ");
		  
		  scanf("%c",&batu); 
		  printf("%d",batu);		//%d te muestra qu� c�digo ASCII es el contenido que hay en la variable
		  //printf("%c",batu);		//%c te muestra el contenido que hay en la variable

		  		 
 
		  
                            
          return 0;
        

}
