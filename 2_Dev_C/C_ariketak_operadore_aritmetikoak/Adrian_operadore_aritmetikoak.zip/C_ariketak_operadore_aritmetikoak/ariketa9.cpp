
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int numlados = 5;
		  
		  float luzera, valorlado;
		  
		  printf("Sartu alde baten balio: ");
          scanf("%f",&valorlado);
          printf("Zenbat alde ditu? = %d \n", numlados);
          //scanf("%d",&zenb2);
          
          luzera = numlados * valorlado;

          
          printf("Luzera = %f \n", luzera);

		  		 
 
		  
                            
          return 0;
        

}
