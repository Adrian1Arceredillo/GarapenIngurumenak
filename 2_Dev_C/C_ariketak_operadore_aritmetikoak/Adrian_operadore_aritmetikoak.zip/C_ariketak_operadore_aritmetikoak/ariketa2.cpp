
#include <stdio.h>
#include <string.h>






int main(){  
          int xaldagaia, yaldagaia;
          int biderketa;
          
          xaldagaia = 5;
          yaldagaia = 3;
          
          biderketa = xaldagaia * yaldagaia;
             
          printf("BIDERKETA: \n");  //komila artekoa bistaratuAdAAko da pantailan 
                    
          printf("\t x=5 \n");
          printf("\t y=3 \n");
          printf("\t \t Emaitza= %d", biderketa);
                            
          return 0;
        

}

