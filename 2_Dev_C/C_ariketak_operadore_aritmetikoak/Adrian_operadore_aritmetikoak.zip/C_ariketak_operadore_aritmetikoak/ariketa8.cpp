
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int xhasiera = 1;
		  int yhasiera = 4;
		  
		  int xfinal;
		  int yfinal;
		  
		  		  
		  printf("ALDAGAI ALDAKETA \n");
		  printf("Sartu 'x'aren balioa: ");
		  scanf("%d",&xfinal);
		  printf("\n Sartu 'y'aren balioa: ");
		  scanf("%d",&yfinal);
		  
		  printf("Hasierakoak: x = %d ", xhasiera);
		  printf(", y = %d\n", yhasiera);
		  printf("Aldatuta: x = %d ", xfinal);
		  printf(", y = %d\n", yfinal);
		  
		  
		  		 
 
		  
                            
          return 0;
        

}
