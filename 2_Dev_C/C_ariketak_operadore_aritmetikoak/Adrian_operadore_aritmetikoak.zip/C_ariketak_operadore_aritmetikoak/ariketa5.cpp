
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int celsius;
		  int cambio = 32;
		  int farenheit;;
		  	
		  
		  printf("Programa honek 'Celsius'-gradutatik \n");
		  printf("Farenheit-era pasatzen du \n \n");
		  printf("Sartu Celsius: ");
		  scanf("%d",&celsius);
		  //printf("El radio es: %d", radio);
		  
		  farenheit = celsius * cambio; 
		  
		  
		  printf("%d C ",celsius);
		  printf("%d F dira",farenheit);
		  
 
		  
                            
          return 0;
        

}
