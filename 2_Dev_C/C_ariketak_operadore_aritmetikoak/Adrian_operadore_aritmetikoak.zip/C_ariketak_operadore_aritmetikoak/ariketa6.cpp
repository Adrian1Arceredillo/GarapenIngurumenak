
#include <stdio.h>
#include <string.h>

int main(){  
          
          
		  
		  int batu;
		  int kenke;
		  int bider;
		  int zati;
		  
		  int zenb1;
		  int zenb2;
		  
		  
		  printf("Zenb1 = ");
          scanf("%d",&zenb1);
          printf("Zenb2 = ");
          scanf("%d",&zenb2);
          
          batu = zenb1 + zenb2;
          kenke = zenb1 - zenb2;
          bider = zenb1 * zenb2;
          zati = zenb1 / zenb2;
          
          printf("Batuketa = zenb1 + zen2 = %d \n", batu);
		  printf("Kenketa = zenb1 - zen2 = %d \n", kenke);
		  printf("Biderketa = zenb1 * zen2 = %d \n", bider);
		  printf("Zatiketa = zenb1 / zen2 = %d \n", zati);
		  		 
 
		  
                            
          return 0;
        

}
